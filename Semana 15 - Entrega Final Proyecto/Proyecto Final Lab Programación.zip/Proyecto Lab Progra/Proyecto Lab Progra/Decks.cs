﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Lab_Progra
{
	internal class Decks
	{
		private string jugador;
		private string equipo;
		private string nom_carta;
		private string tipo_carta;
		private int elixir;
		private int puntos_vida;
		private int daño;
		public string[,] deck;

        public Decks()
		{
			/*declarando el contructor como matriz para guardar la información de cada carta de cada deck*/
			this.deck = new string[8, 5];
		}

        public void AddCard(int puntos_vida, int elixir, int daño, string nom_carta, string tipo, int posicion)
        {
			/*se agrega la información específica de la carta*/
            deck[posicion, 0] = puntos_vida.ToString();
            deck[posicion, 1] = daño.ToString();
            deck[posicion, 2] = elixir.ToString();
            deck[posicion, 3] = nom_carta.ToString();
            deck[posicion, 4] = tipo.ToString();
        }
		public int Imprimirvida()
		{
			/*se imprime el promedio de vida del deck completo y se redondea al entero*/
			int sumavida = 0;
			for(int i = 1; i <= 8; i++)
			{
				int vida = int.Parse(deck[i-1, 0]);
				sumavida += vida;
			}
			return (int)Math.Round((double)sumavida/8);
		}
		public int Imprimirdaño()
		{
            /*se imprime el promedio de daño del deck completo y se redondea al entero*/
            int sumadaño = 0;
            for (int i = 1; i <= 8; i++)
            {
                int vida = int.Parse(deck[i-1, 0]);
                sumadaño += vida;
            }
            return (int)Math.Round((double)sumadaño/8);
        }

		public static string Obtenerganador(Decks deckjugador1, string nickname1, Decks deckjugador2, string nickname2)
		{
			/*crear una condición para determinar el ganador dependiendo quien tiene mayor puntos de daño*/
			if (deckjugador1.Imprimirdaño() > deckjugador2.Imprimirdaño())
			{
				return nickname1 + " Es el ganador";
			}

			else if (deckjugador1.Imprimirdaño() < deckjugador2.Imprimirdaño())
			{
				return nickname2 + " Es el ganador";
			}
			else
			{
				return "Empate";
			}
		}

		public static bool Decknulo(Decks decks)
		{
			/*sera falso cuando los decks no tengan ningun valor*/
			int filas = decks.deck.GetLength(0);
			int columnas = decks.deck.GetLength(1);
			for (int i = 1; i <= filas; i++)
			{
				for (int j = 1; j <= columnas; j++)
				{
					if (decks.deck[i-1,j-1] == null)
					{
						return false;
					}
				}
			}
			return true;
        }
    }
}