﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Proyecto_Lab_Progra;


namespace Proyecto_lab_Progra
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nombreEquipo1 = "";
            string nombreEquipo2 = "";
            string nickname1 = "";
            string nickname2 = "";
            int jugador1eleccion = 0;
            int jugador2eleccion = 0;
            string nickNameJ1 = "";
            string nickNameJ2 = "";

            Decks decks1 = new Decks();
            Decks decks2 = new Decks();
            Decks decks3 = new Decks();
            Decks decks4 = new Decks();

            while (true)
            {
                /*crear un menú*/
                Console.Clear();
                Console.WriteLine("Menú del juego");
                Console.WriteLine("1. Agregar jugadores");
                Console.WriteLine("2. Ver jugadores");
                Console.WriteLine("3. Agregar Decks");
                Console.WriteLine("4. Ver Decks");
                Console.WriteLine("5. Modificar Deck");
                Console.WriteLine("6. Escoger Mazo");
                Console.WriteLine("7. Jugar");
                Console.WriteLine("8. Terminar juego");
                Console.WriteLine("\n");
                Console.Write("Seleccione una opción: ");
                int opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    /*ingresar los nombres de los jugadores y los equipos para nombrar los nicknames*/
                    case 1:
                        Console.Clear();
                        Console.WriteLine("Ingrese el nickname del jugador 1");
                        nickname1 = Console.ReadLine();
                        Console.WriteLine("Ingrese el nombre el equipo 1");
                        nombreEquipo1 = Console.ReadLine();
                        string inicial1 = nombreEquipo1.Substring(0, 1);
                        string inicial2 = nombreEquipo1.Substring(nombreEquipo1.IndexOf(' ') + 1, 1);
                        int length = nickname1.Length - 1;
                        string nicknamen = nickname1.Substring(nickname1.IndexOf(' ') + 1, 1);

                        Console.WriteLine("Ingrese el nickname del jugador 2");
                        nickname2 = Console.ReadLine();
                        Console.WriteLine("Ingrese el nombre el equipo 2");
                        nombreEquipo2 = Console.ReadLine();
                        string inicial12 = nombreEquipo2.Substring(0, 1);
                        string inicial22 = nombreEquipo2.Substring(nombreEquipo2.IndexOf(' ') + 1, 1);
                        int largo = nickname1.Length - 1;
                        string nicknamen2 = nickname2.Substring(nickname1.IndexOf(' ') + 1, 1);
                        
                        nickNameJ1 = inicial1 + inicial2 + " - " + nickname1 + length + nicknamen + "0";
                        nickNameJ2 = inicial12 + inicial22 + " - " + nickname2 + largo + nicknamen2 + "0";
                        Console.WriteLine("\n");
                        Console.WriteLine("Ya se han registrado los nombres y equipos");
                        Console.WriteLine("\n");
                        Console.WriteLine("Presione cualquier tecla para regresar al menu...");
                        Console.ReadKey();
                        break;
                    case 2:
                        /*visualizar los nicknames de los jugadores*/
                        Console.Clear();
                        if (nickNameJ1 != "" && nickNameJ1 != "")
                        {
                            Console.WriteLine("Nombre del jugador 1: " + nickname1);
                            Console.WriteLine("Nombre del equipo 1: " + nombreEquipo1);
                            Console.WriteLine("Nickname del jugador 1: " + nickNameJ1);

                            Console.WriteLine("\nNombre del jugador 2: " + nickname2);
                            Console.WriteLine("Nombre del equipo 2: " + nombreEquipo2);
                            Console.WriteLine("Nickname del jugador 2: " + nickNameJ2);
                        }
                        /*si el usuario ingresa al menu #2 antes de agregar los jugadores, le saldra un aviso que debe ingresar la información antes*/
                        else
                        {
                            Console.WriteLine("Debe agregar jugadores");
                        }

                        Console.WriteLine("\n");
                        Console.WriteLine("Presione cualquier tecla para regresar al menu...");
                        Console.ReadKey();
                        break;
                    case 3:
                        /*ingresar unicamente la información de los cuatro decks*/
                        Console.Clear();
                        Console.WriteLine("Deck #1");
                        for (int i = 1; i <= 8; i++)
                        {
                            string nom; string tipo; int elixir; int pvida; int daño;

                            Console.WriteLine("Ingrese el nombre de la carta " + i);
                            nom = Console.ReadLine();
                            Console.WriteLine("Ingrese el tipo de carta " + i);
                            tipo = Console.ReadLine();
                            Console.WriteLine("Cuantos puntos de vida tiene " + i);
                            pvida = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese el elixir perteneciente a la carta " + i);
                            elixir = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese los puntos de daño que genera la carta " + i);
                            daño = Convert.ToInt32(Console.ReadLine());
                            decks1.AddCard(pvida, elixir, daño, nom, tipo, i - 1);
                        }
                        Console.WriteLine("\n");
                        Console.WriteLine("************************************************");
                        Console.WriteLine("\nDeck #2");
                        for (int i = 1; i <= 8; i++)
                        {
                            string nom; string tipo; int elixir; int pvida; int daño;

                            Console.WriteLine("Ingrese el nombre de la carta " + i);
                            nom = Console.ReadLine();
                            Console.WriteLine("Ingrese el tipo de carta " + i);
                            tipo = Console.ReadLine();
                            Console.WriteLine("Cuantos puntos de vida tiene " + i);
                            pvida = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese el elixir perteneciente a la carta " + i);
                            elixir = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese los puntos de daño que genera la carta " + i);
                            daño = Convert.ToInt32(Console.ReadLine());
                            decks2.AddCard(pvida, elixir, daño, nom, tipo, i - 1);
                        }
                        Console.WriteLine("\n");
                        Console.WriteLine("************************************************");
                        
                        Console.WriteLine("\nDeck #3");
                        for (int i = 1; i <= 8; i++)
                        {
                            string nom; string tipo; int elixir; int pvida; int daño;

                            Console.WriteLine("Ingrese el nombre de la carta " + i);
                            nom = Console.ReadLine();
                            Console.WriteLine("Ingrese el tipo de carta " + i);
                            tipo = Console.ReadLine();
                            Console.WriteLine("Cuantos puntos de vida tiene " + i);
                            pvida = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese el elixir perteneciente a la carta " + i);
                            elixir = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese los puntos de daño que genera la carta " + i);
                            daño = Convert.ToInt32(Console.ReadLine());
                            decks3.AddCard(pvida, elixir, daño, nom, tipo, i - 1);
                        }
                        Console.WriteLine("\n");
                        Console.WriteLine("************************************************");

                        Console.WriteLine("\nDeck #4");
                        for (int i = 1; i <= 8; i++)
                        {
                            string nom; string tipo; int elixir; int pvida; int daño;

                            Console.WriteLine("Ingrese el nombre de la carta " + i);
                            nom = Console.ReadLine();
                            Console.WriteLine("Ingrese el tipo de carta " + i);
                            tipo = Console.ReadLine();
                            Console.WriteLine("Cuantos puntos de vida tiene " + i);
                            pvida = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese el elixir perteneciente a la carta " + i);
                            elixir = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese los puntos de daño que genera la carta " + i);
                            daño = Convert.ToInt32(Console.ReadLine());
                            decks4.AddCard(pvida, elixir, daño, nom, tipo, i - 1);
                        }
                        Console.WriteLine("\n");
                        Console.WriteLine("Agregaste todos los decks");
                        Console.WriteLine("\n");
                        Console.WriteLine("Presione cualquier tecla para regresar al menu...");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case 4:
                        /*Visualizar el promedio total de puntos de daño y puntos de vida de cada deck*/
                        Console.Clear();
                        if (Decks.Decknulo(decks1) && Decks.Decknulo(decks2) && Decks.Decknulo(decks3) && Decks.Decknulo(decks4))
                        {
                            Console.WriteLine("Deck #1");
                            Console.WriteLine("El promedio de daño es: " + decks1.Imprimirdaño());
                            Console.WriteLine("El promedio de vida es: " + decks1.Imprimirvida());

                            Console.WriteLine("\nDeck #2");
                            Console.WriteLine("El promedio de daño es: " + decks2.Imprimirdaño());
                            Console.WriteLine("El promedio de vida es: " + decks2.Imprimirvida());

                            Console.WriteLine("\nDeck #3");
                            Console.WriteLine("El promedio de daño es: " + decks3.Imprimirdaño());
                            Console.WriteLine("El promedio de vida es: " + decks3.Imprimirvida());

                            Console.WriteLine("\nDeck #4");
                            Console.WriteLine("El promedio de daño es: " + decks4.Imprimirdaño());
                            Console.WriteLine("El promedio de vida es: " + decks4.Imprimirvida());
                        }
                        else
                        {
                            Console.WriteLine("Debe agregar los decks");
                        }

                        Console.WriteLine("\n");
                        Console.WriteLine("Presione cualquier tecla para regresar al menu...");
                        Console.ReadKey();
                        break;
                    case 5:
                        /*Modificar la carta deseada de un deck específico*/
                        Console.Clear();
                        if (Decks.Decknulo(decks1) && Decks.Decknulo(decks2) && Decks.Decknulo(decks3) && Decks.Decknulo(decks4))
                        {
                            Console.Write("Ingrese el número de deck que quiere modificar ");
                            int deckmodificar = int.Parse(Console.ReadLine());
                            Console.Write("Ingrese el número de la carta que quiere modificar ");
                            int cartamodificar = int.Parse(Console.ReadLine());

                            string nombremodificado; string tipomodificado; int elixirmodificado; int pvidamodificado; int dañomodificado;
                            Console.WriteLine("\nIngrese el nombre de la carta ");
                            nombremodificado = Console.ReadLine();
                            Console.WriteLine("Ingrese el tipo de carta ");
                            tipomodificado = Console.ReadLine();
                            Console.WriteLine("Cuantos puntos de vida tiene ");
                            pvidamodificado = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese el elixir perteneciente a la carta ");
                            elixirmodificado = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Ingrese los puntos de daño que genera la carta ");
                            dañomodificado = Convert.ToInt32(Console.ReadLine());

                            /*Con el deck elegido, buscar el dato de la carta dependiendo del numero del deck y carta*/
                            if (deckmodificar == 1)
                            {
                                decks1.deck[cartamodificar - 1, 0] = pvidamodificado.ToString();
                                decks1.deck[cartamodificar - 1, 1] = dañomodificado.ToString();
                                decks1.deck[cartamodificar - 1, 2] = elixirmodificado.ToString();
                                decks1.deck[cartamodificar - 1, 3] = nombremodificado.ToString();
                                decks1.deck[cartamodificar - 1, 4] = tipomodificado.ToString();
                            }
                            else if (deckmodificar == 2)
                            {
                                decks2.deck[cartamodificar - 1, 0] = pvidamodificado.ToString();
                                decks2.deck[cartamodificar - 1, 1] = dañomodificado.ToString();
                                decks2.deck[cartamodificar - 1, 2] = elixirmodificado.ToString();
                                decks2.deck[cartamodificar - 1, 3] = nombremodificado.ToString();
                                decks2.deck[cartamodificar - 1, 4] = tipomodificado.ToString();
                            }
                            else if (deckmodificar == 3)
                            {
                                decks3.deck[cartamodificar - 1, 0] = pvidamodificado.ToString();
                                decks3.deck[cartamodificar - 1, 1] = dañomodificado.ToString();
                                decks3.deck[cartamodificar - 1, 2] = elixirmodificado.ToString();
                                decks3.deck[cartamodificar - 1, 3] = nombremodificado.ToString();
                                decks3.deck[cartamodificar - 1, 4] = tipomodificado.ToString();
                            }
                            else if (deckmodificar == 4)
                            {
                                decks4.deck[cartamodificar - 1, 0] = pvidamodificado.ToString();
                                decks4.deck[cartamodificar - 1, 1] = dañomodificado.ToString();
                                decks4.deck[cartamodificar - 1, 2] = elixirmodificado.ToString();
                                decks4.deck[cartamodificar - 1, 3] = nombremodificado.ToString();
                                decks4.deck[cartamodificar - 1, 4] = tipomodificado.ToString();
                            }
                            Console.WriteLine("El deck #" + deckmodificar + " ha sido modificado");
                        }
                        else
                        {
                            Console.WriteLine("Debe agregar el deck a modificar");
                        }

                        Console.WriteLine("\n");
                        Console.WriteLine("Presione cualquier tecla para regresar al menu...");
                        Console.ReadKey();
                        break;
                    case 6:
                        /*Escoger el mazo de cada jugador con el numero de deck dependiendo en el orden en que lo agrego al sistema*/
                        Console.Clear();
                        if (nickNameJ1 != "" && nickNameJ2 != "")
                        {
                            Console.Write("Mazo jugador 1: ");
                            jugador1eleccion = int.Parse(Console.ReadLine());
                            Console.Write("\nMazo jugador 2: ");
                            jugador2eleccion = int.Parse(Console.ReadLine());
                        }
                        else
                        {
                            Console.WriteLine("Debe agregar jugadores");
                        }
                        Console.WriteLine("\n");
                        Console.WriteLine("Presione cualquier tecla para regresar al menu...");
                        Console.ReadKey();
                        break;
                    case 7:
                        /*en esta sección del menú se evalúa que jugador ganará dependiendo del deck escogido*/
                        Console.Clear();
                        if ((jugador1eleccion > 0) && (jugador2eleccion > 0))
                        {
                            Decks deckjugador1 = new Decks();
                            Decks deckjugador2 = new Decks();
                            switch (jugador1eleccion)
                            {
                                case 1:
                                    deckjugador1 = decks1;
                                    break;
                                case 2:
                                    deckjugador1 = decks2;
                                    break;
                                case 3:
                                    deckjugador1 = decks3;
                                    break;
                                case 4:
                                    deckjugador1 = decks4;
                                    break;
                            }
                            switch (jugador2eleccion)
                            {
                                case 1:
                                    deckjugador2 = decks1;
                                    break;
                                case 2:
                                    deckjugador2 = decks2;
                                    break;
                                case 3:
                                    deckjugador2 = decks3;
                                    break;
                                case 4:
                                    deckjugador2 = decks4;
                                    break;
                            }
                            string ganador = Decks.Obtenerganador(deckjugador1, nickname1, deckjugador2, nickname2);
                            Console.WriteLine(ganador);
                        }
                        else
                        {
                            Console.WriteLine("Debe seleccionar el deck para cada jugador");
                        }
                        Console.WriteLine("\n");
                        Console.WriteLine("Presione cualquier tecla para regresar al menu...");
                        Console.ReadKey();
                        break;
                    case 8:
                        /*en esta sección le permite al jugador terminar el juego*/
                        Environment.Exit(0);
                        break;
                }
            }
        }
    }
}