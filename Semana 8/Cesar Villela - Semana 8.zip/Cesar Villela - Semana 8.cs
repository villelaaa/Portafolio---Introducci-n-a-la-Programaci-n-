﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

namespace Semana_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese un número entero positivo: ");

            int numero;
            while (!int.TryParse(Console.ReadLine(), out numero) || numero <= 0)
            {
                Console.Write("Número no válido. Intente de nuevo: ");
            }

            double sumaUno = CalcularSumaUno(numero);
            double sumaDos = CalcularSumaDos(numero);

            Console.WriteLine($"La suma de (1 / 1) + (1 / 2) + (1 / 3) + ... + (1 / {numero}) es igual a {sumaUno}");
            Console.WriteLine($"La suma de (1 / 2^1) + (1 / 2^2) + (1 / 2^3) + ... + (1 / 2^{numero}) es igual a {sumaDos}");

            Console.ReadKey();
        }

        static double CalcularSumaUno(int n)
        {
            double sumaUno = 0;
            for (int i = 1; i <= n; i++)
            {
                sumaUno += 1.0 / i;
            }
            return sumaUno;
        }

        static double CalcularSumaDos(int n)
        {
            double sumaDos = 0;
            for (int i = 1; i <= n; i++)
            {
                sumaDos += 1.0 / Math.Pow(2, i);
            }
            return sumaDos;
        }
    }
}
