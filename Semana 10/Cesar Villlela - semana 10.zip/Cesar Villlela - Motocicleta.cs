﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Semana__10 
{
    using System;

    class Motocicleta
    {
        public int Modelo { get; set; } = 2019;
        public double Precio { get; private set; } = 1000;
        public string Marca { get; set; } = "";
        public double Iva { get; private set; } = 0.12;

        public Motocicleta()
        {
        }

        public Motocicleta(int modelo, string marca, double precio, double iva)
        {
            Modelo = modelo;
            Marca = marca;
            DefinirPrecio(precio);
            DefinirIva(iva);
        }

        public string MostrarDatos()
        {
            return $"Modelo: {Modelo}, Marca: {Marca}, Precio sin IVA: {Precio:C}, IVA: {Iva:P}";
        }

        public void DefinirPrecio(double precio)
        {
            if (precio >= 0)
            {
                Precio = precio;
            }
            else
            {
                Console.WriteLine("El precio no puede ser negativo. Se mantendrá el precio actual.");
            }
        }

        public void DefinirIva(double iva)
        {
            if (iva >= 0.01 && iva <= 0.99)
            {
                Iva = iva;
            }
            else
            {
                Console.WriteLine("El porcentaje de IVA debe estar en el rango de 0.01 a 0.99. Se mantendrá el IVA actual.");
            }
        }
    }

