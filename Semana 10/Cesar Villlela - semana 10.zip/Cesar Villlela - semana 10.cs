﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Semana_10 
{
    using System;

    class Program
    {
        static void Main()
        {
            Motocicleta objMotocicleta = CrearMotocicletaDesdeEntrada();

            Console.WriteLine("\nDatos de la motocicleta:");
            Console.WriteLine(objMotocicleta.MostrarDatos());

            Console.WriteLine($"\nPrecio sin IVA: {objMotocicleta.PrecioSinIva():C}");
            Console.WriteLine($"Precio con IVA: {objMotocicleta.PrecioConIva():C}");
            Console.WriteLine($"Monto del IVA: {objMotocicleta.DevolverIva():C}");

            Console.ReadKey();
        }

        static Motocicleta CrearMotocicletaDesdeEntrada()
        {
            Motocicleta objMotocicleta = new Motocicleta();

            Console.Write("Modelo: ");
            objMotocicleta.Modelo = int.Parse(Console.ReadLine());

            Console.Write("Marca: ");
            objMotocicleta.Marca = Console.ReadLine();

            Console.Write("Precio sin IVA: ");
            double precioSinIva = double.Parse(Console.ReadLine());
            objMotocicleta.DefinirPrecio(precioSinIva);

            Console.Write("Porcentaje de IVA (0.01 a 0.99): ");
            double porcentajeIva = double.Parse(Console.ReadLine());
            objMotocicleta.DefinirIva(porcentajeIva);

            return objMotocicleta;
        }
    }


