﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea1___Lab_12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TrianguloRectangulo objtriangulo = new TrianguloRectangulo();

            Console.WriteLine("Ingrese el valor de un cateto");
            double CatetoA = LeerDouble();

            Console.WriteLine("Ingrese el valor del ángulo opuesto a este, en grados");
            double AnguloOpuesto = LeerDouble();

            objtriangulo.SetCatetos(CatetoA, AnguloOpuesto);
            objtriangulo.ObtenerDatos();

            Console.ReadKey();
        }

        static double LeerDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double valor))
                {
                    return valor;
                }
                else
                {
                    Console.WriteLine("Entrada no válida. Intente nuevamente.");
                }
            }
        }
    }
}
