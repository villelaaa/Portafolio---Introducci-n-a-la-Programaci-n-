﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea - semana2
{
    internal class TrianguloRectangulo
{
    private double catetoA;
    private double anguloOpuestoA;

    public void SetCatetos(double catetoA, double anguloOpuestoA)
    {
        this.catetoA = catetoA;
        this.anguloOpuestoA = anguloOpuestoA * (Math.PI / 180); // Convierte a radianes
    }

    public double ObtenerCatetoA()
    {
        return catetoA;
    }

    public double ObtenerCatetoB()
    {
        return catetoA / Math.Tan(anguloOpuestoA);
    }

    public double ObtenerHipotenusa()
    {
        return catetoA / Math.Sin(anguloOpuestoA);
    }

    public double ObtenerAnguloOpuestoA()
    {
        return anguloOpuestoA * (180 / Math.PI); // Convierte a grados
    }

    public double ObtenerAnguloOpuestoB()
    {
        return 90 - ObtenerAnguloOpuestoA();
    }

    public double ObtenerArea()
    {
        return (ObtenerCatetoA() * ObtenerCatetoB()) / 2;
    }

    public void ObtenerDatos()
    {
        Console.WriteLine("\nEl valor del cateto a es: " + ObtenerCatetoA().ToString("0.000"));
        Console.WriteLine("El valor del cateto b es: " + ObtenerCatetoB().ToString("0.000"));
        Console.WriteLine("El valor de la hipotenusa es: " + ObtenerHipotenusa().ToString("0.000"));
        Console.WriteLine("El valor del ángulo opuesto de a es: " + ObtenerAnguloOpuestoA().ToString("0.000"));
        Console.WriteLine("El valor del ángulo opuesto de b es: " + ObtenerAnguloOpuestoB().ToString("0.000"));
        Console.WriteLine("El valor del área del triángulo es: " + ObtenerArea().ToString("0.000"));
    }
}
